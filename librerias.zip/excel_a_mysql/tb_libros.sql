CREATE TABLE tb_libros(
  id                  INT    ( 11)  NOT NULL AUTO_INCREMENT PRIMARY KEY,
	titulo              VARCHAR(255)	NULL,
	autor               VARCHAR(255)	NULL,
	ano_publicacion     VARCHAR(255)	NULL,
	paginas             VARCHAR(255)	NULL,
	estado    			    VARCHAR(10) 	NULL
);
